perl ./perl/frgrpin11.pl > process-classes-1.log
