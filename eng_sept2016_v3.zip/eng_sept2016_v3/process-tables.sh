perl ./perl/frin11.pl > process-tables-1.log
